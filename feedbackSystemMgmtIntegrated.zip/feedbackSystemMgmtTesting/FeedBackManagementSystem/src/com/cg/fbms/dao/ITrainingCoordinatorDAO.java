package com.cg.fbms.dao;

import java.util.Date;
import java.util.List;

import com.cg.fbms.dto.Faculty;
import com.cg.fbms.dto.TrainingProgram;

public interface ITrainingCoordinatorDAO {
	public boolean addTrainingCourse(TrainingProgram TrainingP);

	public List<TrainingProgram> showTrainingCourse() throws Exception;

	public TrainingProgram findTrainingCourse(int id);

	public Boolean updateTrainingCourse(TrainingProgram training);

	public Boolean validateDuplicate(TrainingProgram trainingP);

	public Boolean deleteTrainingCourse(int trainingId);

}


