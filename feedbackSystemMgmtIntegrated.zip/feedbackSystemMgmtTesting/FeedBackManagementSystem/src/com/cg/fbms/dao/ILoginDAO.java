package com.cg.fbms.dao;

import com.cg.fbms.dto.Employee;

public interface ILoginDAO {
	
    public Employee validateEmployee(Employee employee);

	

}
