package com.cg.fbms.service;

import java.util.Date;
import java.util.List;

import com.cg.fbms.dto.TrainingProgram;

public interface ITrainingCoordinatorService {
	
	public boolean addTrainingSession(TrainingProgram trainingProgram);

	public List<TrainingProgram> showTrainingCourse();

	public Boolean updateTrainingSession(TrainingProgram training);

	public TrainingProgram findTrainingSession(int id);

	public Boolean deleteTrainingSession(int trainingId);

	public Boolean validateDuplicate(TrainingProgram trainingP);

	public boolean dateValidation(Date startDate, Date endDate);
	

	

	}
