package com.cg.fbms.exception;

public class FeedbackSystemException extends Exception{
	
	public FeedbackSystemException(String message) {	
		super(message);
	}

}
