package com.cg.fbms.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceException;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.cg.fbms.dto.Employee;
import com.cg.fbms.dto.Faculty;
import com.cg.fbms.dto.TrainingProgram;
import com.cg.fbms.utility.JPAUtility;

public class TrainingCoordinatorDAO implements ITrainingCoordinatorDAO , QueryConstants {

	EntityManagerFactory  factory = null;
	EntityManager manager = null;
	EntityTransaction transaction = null;
	
	@Override
	public List<TrainingProgram> showTrainingCourse() throws Exception {
		
		factory = JPAUtility.getFactory();
		manager = factory.createEntityManager();
		List<TrainingProgram> trainingsList = null;
		try {
			TypedQuery<TrainingProgram> query = manager.createQuery(GET_ALL_TRAINING_COURSE, TrainingProgram.class);
			trainingsList = query.getResultList();
			if(trainingsList == null || trainingsList.size() == 0) {
				throw new Exception("No data Found...");
			}
		}
		finally {
			manager.close();
		}
		return trainingsList;
	}
	
	@Override
	public boolean addTrainingCourse(TrainingProgram TrainingP) {
		//transaction
		
		factory = JPAUtility.getFactory();
		manager = factory.createEntityManager();
		transaction = manager.getTransaction();
		
		boolean status = false;
		
		try {
			transaction.begin();
			manager.persist(TrainingP);
			transaction.commit();
			status = true;
		}
		catch (Exception e) {
			
			transaction.rollback();
		}
		finally {
			manager.close();
			}
		return status;
	}
	
	
	@Override
	public TrainingProgram findTrainingCourse(int id) {
		
		factory = JPAUtility.getFactory();
		manager = factory.createEntityManager();
		TrainingProgram training = null;
		try {
			
			training = manager.find(TrainingProgram.class, id);
		}
		catch (PersistenceException p) {
			// TODO: handle exception
			System.err.println(p.getMessage());
		}
		return training;
	}
	
	@Override
	public Boolean updateTrainingCourse(TrainingProgram training) {
		
		
		factory = JPAUtility.getFactory();
		manager = factory.createEntityManager();
		transaction = manager.getTransaction();
		boolean status = false;
		
		try {
			
			transaction.begin();
			manager.merge(training);
			transaction.commit();
			status = true;
		}
		catch (PersistenceException p) {
			transaction.rollback();
			System.err.println(p.getMessage());
		}
		return status;
	}

	@Override
	public Boolean deleteTrainingCourse(int trainingId) {
		
		factory = JPAUtility.getFactory();
		manager = factory.createEntityManager();
		transaction = manager.getTransaction();
		
		boolean status = false;
		
		try {
			transaction.begin();
			TrainingProgram training = manager.find(TrainingProgram.class, trainingId);
			manager.remove(training);
			transaction.commit();
			status = true;
		}
		catch(PersistenceException p) {
			transaction.rollback();
			System.err.println(p.getMessage());
		}
		return status;
	}

	@Override
	public Boolean validateDuplicate(TrainingProgram trainingP) {
	
		int duplicateCount=0;
		Boolean status = false;
		List<TrainingProgram> trainingsList = null;		
		factory = JPAUtility.getFactory();
		manager = factory.createEntityManager();
		
		try {			
			TypedQuery<TrainingProgram> query = manager.createQuery(GET_ALL_TRAINING_COURSE, TrainingProgram.class);
			trainingsList = query.getResultList();
		}
		catch (PersistenceException p) {
			// TODO: handle exception
			System.err.println(p.getMessage());
		}
		finally {
			manager.close();
		}
		
		
		if(trainingsList.size()!=0) {			
			for(TrainingProgram trainingIterator: trainingsList) {
				if(trainingIterator.getCourseId()==trainingP.getCourseId()&&
						trainingIterator.getFacultyId()==trainingP.getFacultyId()
						)
				{
					if(trainingIterator.getTrainingStartDate().getDate()==trainingP.getTrainingStartDate().getDate()&&
							trainingIterator.getTrainingStartDate().getMonth()==trainingP.getTrainingStartDate().getMonth()&&
							trainingIterator.getTrainingStartDate().getYear()==trainingP.getTrainingStartDate().getYear()) 
					{
						
						if(trainingIterator.getTrainingEndDate().getDate()==trainingP.getTrainingEndDate().getDate()&&
								trainingIterator.getTrainingEndDate().getMonth()==trainingP.getTrainingEndDate().getMonth()&&
								trainingIterator.getTrainingEndDate().getYear()==trainingP.getTrainingEndDate().getYear())
						{
							duplicateCount++;
							
							break;
						}
					}
				}
				System.out.println(trainingIterator.getTrainingStartDate().getDate()+"  "+trainingP.getTrainingStartDate().getDate());
			}
			System.out.println(duplicateCount);
			if(duplicateCount==0)
				status = true;
			
		}
		else {
			System.out.println("in else part");
			status = true;
		}
			return status;
		
	}
}


