package com.cg.fbms.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceException;

import com.cg.fbms.dto.Employee;
import com.cg.fbms.utility.JPAUtility;

public class LoginDAOImpl implements ILoginDAO{
	
	private String employeeRole = null;
	private String employeeName = null;

	
	
	@Override
	public boolean validateEmployee(Employee employee) {
		// TODO Auto-generated method stub

		EntityManagerFactory factory = null;
		EntityManager manager = null;
		factory = JPAUtility.getFactory();
		manager = factory.createEntityManager();
		boolean status = false;
		try {
			Employee employeeInfo = manager.find(Employee.class, employee.getEmployeeId());
			if(employeeInfo.getEmployeePassword().equals(employee.getEmployeePassword())) {
				employeeRole = employeeInfo.getEmployeeRole();
				employeeName = employeeInfo.getEmployeeName();
				status = true;
			}
				

		} 
		catch (PersistenceException e) {
			System.err.println(e.getMessage());
		}
		return status;
		
	}


	
	@Override
	public String getEmployeeRole() {
		// TODO Auto-generated method stub
		return employeeRole;
	}

	@Override
	public String getEmployeeName() {
		// TODO Auto-generated method stub
		return employeeName;
	}
	
	
	

}
