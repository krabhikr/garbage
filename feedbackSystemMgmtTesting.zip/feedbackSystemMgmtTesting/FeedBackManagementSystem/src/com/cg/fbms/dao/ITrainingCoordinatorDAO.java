package com.cg.fbms.dao;

import java.util.Date;

import com.cg.fbms.dto.Faculty;
import com.cg.fbms.dto.TrainingProgram;

public interface ITrainingCoordinatorDAO {
	public boolean addTrainingCourse(TrainingProgram TrainingP);

}


