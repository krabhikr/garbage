package com.cg.fbms.dao;
import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceException;
import javax.persistence.Query;

import com.cg.fbms.dto.CourseMaster;
import com.cg.fbms.utility.JPAUtility;

public class CourseMaintenanceDAO implements ICourseMaintenanceDAO,QueryConstants {
	EntityManagerFactory factory = null;
	EntityManager manager = null;
	EntityTransaction transaction = null;
	
	@Override
	public boolean addCourse(CourseMaster courseMaster) {
		// TODO Auto-generated method stub
		
		factory = JPAUtility.getFactory();
		manager = factory.createEntityManager();
		transaction = manager.getTransaction();
		
		boolean status=false;
		
		try {
			transaction.begin();
			System.out.println("BEFORE PERSEIST");
			manager.persist(courseMaster);
			System.out.println("AFTER PERSEIST");
			transaction.commit();
			System.out.println("AFTER COMMIT");
			status = true;
		} 
		catch (PersistenceException c) {
			transaction.rollback();
			System.err.println(c.getMessage());
			
		}
		finally {
			manager.close();
		}
		return status;
	}

	@Override
	public boolean changeCourseName(int courseId, String courseName) {
		// TODO Auto-generated method stub
		factory = JPAUtility.getFactory();
		manager = factory.createEntityManager();
		transaction = manager.getTransaction();
		boolean status=false;
		
		try {
			transaction.begin();
			CourseMaster courseMaster = manager.find(CourseMaster.class, courseId);
			courseMaster.setCourseName(courseName);
			transaction.commit();
			status= true;;
		}
		catch (PersistenceException c) {
			transaction.rollback();
			System.err.println(c.getMessage());
		} 
		finally {
			manager.close();
		}
		
		return status;

	}

	@Override
	public boolean changeCourseDuration(int courseId, int courseDays) {
		// TODO Auto-generated method stub
		factory = JPAUtility.getFactory();
		manager = factory.createEntityManager();
		transaction = manager.getTransaction();
		boolean status=false;

		try {
			transaction.begin();
			CourseMaster courseMaster = manager.find(CourseMaster.class, courseId);
			courseMaster.setCourseDays(courseDays);
			transaction.commit();
			status =  true;
		} 
		catch (PersistenceException c) {
			transaction.rollback();
			System.err.println(c.getMessage());
		}
		finally {
			manager.close();
		}
		
		return status;
	}

	@Override
	public CourseMaster getCourseById(int courseId) {
		// TODO Auto-generated method stub
		factory = JPAUtility.getFactory();
		manager = factory.createEntityManager();
		
		
		CourseMaster courseMaster = null;
		
		try {
			courseMaster = manager.find(CourseMaster.class, courseId);
			
		} 
		catch (PersistenceException c) {
			System.err.println(c.getMessage());
		}
		finally {
			manager.close();
		}

		return courseMaster;
	}

	
	@Override
	public ArrayList <CourseMaster> getAllCourse() {
		// TODO Auto-generated method stub
		ArrayList<CourseMaster> allCourseList = new ArrayList<CourseMaster>();
		factory = JPAUtility.getFactory();
		manager = factory.createEntityManager();
		
		try {
			allCourseList =	(ArrayList<CourseMaster>)manager.createQuery(GET_ALL_COURSE_LIST,CourseMaster.class).getResultList();
		}
		catch (PersistenceException p) {
			// TODO: handle exception
			System.err.println(p.getMessage());
		}
		finally {
			manager.close();
		}
		
		return allCourseList;
	}

	@Override
	public boolean checkCourseExistence(String couresName) {
		// TODO Auto-generated method stub
		factory = JPAUtility.getFactory();
		manager = factory.createEntityManager();
		CourseMaster course = null;
		boolean status = false;
		try {
			System.out.println("in try block");
			Query query = manager.createQuery(CHECK_COURSE_EXISTENCE,CourseMaster.class);
			System.out.println("in try block");
			query.setParameter(1, couresName);
			System.out.println("in try block");
			course = (CourseMaster) query.getSingleResult();
			System.out.println("in try block");
			//System.out.println("came in dao "+ "name is " + course.getCourseName());
			if(course!=null) {
				status = true;
			}
		}
		catch (PersistenceException p) {
			// TODO: handle exception
			System.out.println("in exception");
			System.err.println(p.getMessage());
		}
		return status;
	}

	@Override
	public CourseMaster getCourseByCourseName(String courseName) {
		// TODO Auto-generated method stub
		factory = JPAUtility.getFactory();
		manager = factory.createEntityManager();
		CourseMaster course = null;
		boolean status = false;
		try {
			Query query = manager.createQuery(CHECK_COURSE_EXISTENCE,CourseMaster.class);
			query.setParameter(1, courseName);
			course = (CourseMaster) query.getSingleResult();
			//System.out.println("came in dao "+ "name is " + course.getCourseName());
			
		}
		catch (PersistenceException p) {
			// TODO: handle exception
			System.out.println("in exception");
			System.err.println(p.getMessage());
		}
		return course;
	}

}
