package com.cg.fbms.service;

import java.util.Date;

import com.cg.fbms.dto.TrainingProgram;

public interface ITrainingCoordinatorService {
	
	public boolean addTrainingSession(TrainingProgram trainingProgram);
	

	

	}
