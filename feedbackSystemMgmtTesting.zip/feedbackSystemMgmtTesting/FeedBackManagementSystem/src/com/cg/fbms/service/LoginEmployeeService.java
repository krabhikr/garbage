package com.cg.fbms.service;

import com.cg.fbms.dao.EmployeeDAO;
import com.cg.fbms.dao.ILoginDAO;
import com.cg.fbms.dao.LoginDAOImpl;
import com.cg.fbms.dto.Employee;

public class LoginEmployeeService implements ILoginEmployee{

	
	@Override
	public boolean loginAuthentication(Employee employee) {
		
		if(employee.getEmployeeId() > 1 &&  employee.getEmployeePassword()!=null && employee.getEmployeePassword()!="") {
			
			ILoginDAO loginDao = new LoginDAOImpl();
			boolean loginStatus = loginDao.validateEmployee(employee);
			return loginStatus;
		}
		 return false;
		
	}

}
