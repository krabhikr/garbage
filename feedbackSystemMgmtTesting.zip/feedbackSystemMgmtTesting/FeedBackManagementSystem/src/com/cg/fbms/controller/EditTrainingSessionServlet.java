package com.cg.fbms.controller;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.fbms.dto.TrainingProgram;
import com.cg.fbms.service.ITrainingCoordinatorService;
import com.cg.fbms.service.TrainingCoordinatorService;

@WebServlet("/EditTrainingSessionServlet")
public class EditTrainingSessionServlet extends HttpServlet{
	ITrainingCoordinatorService trainingService = new TrainingCoordinatorService();
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int trainingID = Integer.parseInt(request.getParameter("trainingId"));
		int courseID = Integer.parseInt(request.getParameter("course"));
		int facultyID = Integer.parseInt(request.getParameter("faculty"));
		Date startDate = null;
		try {
			startDate = new SimpleDateFormat("yyyy-MM-dd").parse(request.getParameter("startDate"));
		} catch (ParseException e) {
			
			e.printStackTrace();
		}

		Date endDate = null;
		try {
			endDate = new SimpleDateFormat("yyyy-MM-dd").parse(request.getParameter("endDate"));
		} catch (ParseException e) {
			
			e.printStackTrace();
		}
		TrainingProgram trainingBeforeUpdate = trainingService.findTrainingSession(trainingID);
		System.out.println("Before updating");
		System.out.println(trainingBeforeUpdate.getTrainingId()+" "+trainingBeforeUpdate.getCourseId()
			+" "+trainingBeforeUpdate.getFacultyId()+" "+trainingBeforeUpdate.getTrainingStartDate()
			+" "+trainingBeforeUpdate.getTrainingEndDate());

		TrainingProgram training = trainingService.findTrainingSession(trainingID);
		training.setCourseId(courseID);
		training.setFacultyId(facultyID);
		training.setTrainingStartDate(startDate);
		training.setTrainingEndDate(endDate);
		
		if(trainingService.dateValidation(startDate, endDate)){
			request.getSession().removeAttribute("errorDuplicate");
			request.getSession().setAttribute("errorStartDate", "Start date was greater than End date, please re-enter");
			response.sendRedirect("edit.jsp?id="+training.getTrainingId());
		}
		else
		{
			Boolean duplicateEntry = trainingService.validateDuplicate(training);
			if(!duplicateEntry) {
				request.getSession().removeAttribute("errorStartDate");
				request.getSession().setAttribute("errorDuplicate", "An entry with same CourseID exists");
				response.sendRedirect("edit.jsp?id="+training.getTrainingId());
			}
			else {
				Boolean update = trainingService.updateTrainingSession(training);

				System.out.println("After updating");
				System.out.println(training.getTrainingId()+" "+training.getCourseId()+" "
						+training.getFacultyId()+" "+training.getTrainingStartDate()+" "
						+training.getTrainingEndDate());
				response.sendRedirect("editOrDelete.jsp");
			if(update)
				System.out.println("Data persisted");
			else
				System.out.println("Couldn't persist");
			}
		}
		
	}
	
	
}
	