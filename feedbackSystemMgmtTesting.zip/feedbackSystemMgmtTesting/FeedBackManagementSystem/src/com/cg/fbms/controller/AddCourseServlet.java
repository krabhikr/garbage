package com.cg.fbms.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.coyote.Request;

import com.cg.fbms.dao.CourseMaintenanceDAO;
import com.cg.fbms.dao.ICourseMaintenanceDAO;
import com.cg.fbms.dto.CourseMaster;
import com.cg.fbms.service.CourseMaintenanceService;
import com.cg.fbms.service.ICourseMaintenance;

@WebServlet("/AddCourseServlet")
public class AddCourseServlet extends HttpServlet {
   
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		if(request.getSession().getAttribute("username")==null || request.getSession().getAttribute("username")!=null) {
			response.sendRedirect("welcome.jsp");
		}
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String courseName = request.getParameter("courseName");
		Integer courseDays = Integer.parseInt(request.getParameter("courseDuration"));
		
		
		RequestDispatcher dispatcher = null;
		CourseMaster courseMaster = new CourseMaster(courseName,courseDays);
		
		try {
			ICourseMaintenance courseMaintenance = new CourseMaintenanceService();
			System.out.println("TRY 1");
			boolean status = courseMaintenance.addCourse(courseMaster);
			System.out.println("TRY 1");
			if(status) {
				System.out.println("Course added Successfully");
				request.setAttribute("successMessage", "Course added successfully");
				dispatcher = request.getRequestDispatcher("addCourse.jsp");
				dispatcher.forward(request, response);
				
			}
			else {
				request.setAttribute("errorMessage", "Some error occurred, please verify all details");
				dispatcher = request.getRequestDispatcher("addCourse.jsp");
				dispatcher.forward(request, response);
			}
			
		}
		
		catch (Exception e) {
			// TODO: handle exception
			System.out.println("CATCH 1");
			request.setAttribute("error", "Sorry can't connect to databse");
			dispatcher = request.getRequestDispatcher("errorPage.jsp");
			dispatcher.forward(request, response);
		}
		
		
	}

}
