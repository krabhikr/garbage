package com.cg.fbms.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.fbms.dto.CourseMaster;
import com.cg.fbms.dto.Faculty;
import com.cg.fbms.service.CourseMaintenanceService;
import com.cg.fbms.service.FacultyMaintenanceService;
import com.cg.fbms.service.ICourseMaintenance;
import com.cg.fbms.service.IFacultyMaintenance;



@WebServlet("/GetFacultyNotMappedWithCourseServlet")
public class GetFacultyNotMappedWithCourseServlet extends HttpServlet{
	
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
			// TODO Auto-generated method stub
			
	
		
		
		
		
		RequestDispatcher dispatcher = null;
		ArrayList<Faculty> facultyList = new ArrayList<>();
		try {
			
			IFacultyMaintenance facultyMaintenance = new FacultyMaintenanceService();
			ICourseMaintenance courseMaintenance = new CourseMaintenanceService();
			int courseId = Integer.parseInt(request.getParameter("selectedCourseName"));
			if(courseId!=-1) {
				CourseMaster course = courseMaintenance.getCourseById(courseId);	
				facultyList = facultyMaintenance.getFacultyNotMappedWithCourse(course);
			}
			
			
			request.setAttribute("courseId", courseId);
			request.setAttribute("facultyList", facultyList);
			System.out.println(facultyList.size());
			request.getRequestDispatcher("facultyMaintenance.jsp").forward(request, response);
		}
		catch (Exception e) {
			// TODO: handle exception
			request.setAttribute("ErrorMsg", "Sorry can't connect to database.");
			request.getRequestDispatcher("error.jsp").forward(request, response);
		}
		
	}
	
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
	}
}

