package com.cg.fbms.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.fbms.service.CourseMaintenanceService;
import com.cg.fbms.service.ICourseMaintenance;

@WebServlet("/CheckCourseExistence")
public class CheckCourseExistenceServlet extends HttpServlet{
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String courseName = request.getParameter("courseName");
		System.out.println("course name " + courseName);
		RequestDispatcher dispatcher = null;
		try {
			System.out.println("caaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaammmmmmmmmmmm");
			ICourseMaintenance courseMaintenance = new CourseMaintenanceService();
			boolean isExist = courseMaintenance.checkCourseExistence(courseName);
			System.out.println("status " + isExist);
			if(isExist) {
				System.out.println("working fine");
				request.setAttribute("errorMessage", "Course already exist");
				dispatcher = request.getRequestDispatcher("addCourse.jsp");
				dispatcher.forward(request, response);
				
			}
			else{
				System.out.println("in else loop");
				request.setAttribute("courseName", courseName);
				dispatcher = request.getRequestDispatcher("addCourse.jsp");
				dispatcher.forward(request, response);
			}
		
		}catch (Exception e) {
			// TODO: handle exception
		}
	}
}
