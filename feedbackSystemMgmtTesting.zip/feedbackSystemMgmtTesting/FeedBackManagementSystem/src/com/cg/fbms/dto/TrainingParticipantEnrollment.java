package com.cg.fbms.dto;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Training_Participant_Enrollment")
public class TrainingParticipantEnrollment {
	@Id
	//@GeneratedValue
	@EmbeddedId
	TrainingParticipantId trainingParticipantId;

	public TrainingParticipantEnrollment() {
		super();
	}

	public TrainingParticipantEnrollment(TrainingParticipantId trainingParticipantId) {
		super();
		this.trainingParticipantId = trainingParticipantId;
	}

	public TrainingParticipantId getTrainingParticipantId() {
		return trainingParticipantId;
	}

	public void setTrainingParticipantId(TrainingParticipantId trainingParticipantId) {
		this.trainingParticipantId = trainingParticipantId;
	}

	@Override
	public String toString() {
		return "TrainingParticipantEnrollment [trainingParticipantId=" + trainingParticipantId + "]";
	}
	

	
	

}
