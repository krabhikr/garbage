package com.cg.fbms.service;

import com.cg.fbms.dao.EmployeeDAO;
import com.cg.fbms.dao.IEmployeeDAO;

public class EmployeeService implements IEmployee {

	IEmployeeDAO employeeDAO = new EmployeeDAO();
	
	@Override
	public String getEmployeeNameById(int empId) {
		return employeeDAO.getEmployeeNameById(empId);
	}

}
