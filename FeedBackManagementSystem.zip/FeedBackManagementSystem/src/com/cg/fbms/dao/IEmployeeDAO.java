package com.cg.fbms.dao;

import com.cg.fbms.dto.Employee;

public interface IEmployeeDAO {

	public boolean addEmployee(Employee employee);
	
	public String getEmployeeNameById(int empId);
	
}
