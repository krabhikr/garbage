package com.cg.fbms.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.fbms.dao.ILoginDAO;
import com.cg.fbms.dao.LoginDAOImpl;
import com.cg.fbms.dto.Employee;
import com.cg.fbms.service.ILoginEmployee;
import com.cg.fbms.service.LoginEmployeeService;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
			if(request.getSession().getAttribute("username")==null || request.getSession().getAttribute("username")!=null) {
				response.sendRedirect("welcome.jsp");
			}
	}
	 
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		ILoginEmployee loginEmployee = new LoginEmployeeService();		
		int employeeId =  Integer.parseInt(request.getParameter("userName"));
		String employeePassword = request.getParameter("password");	
		Employee employeeCredentials = new Employee(employeeId,employeePassword);
		
		try {
			
			boolean isValidEmployee = loginEmployee.loginAuthentication(employeeCredentials);
			
			if(isValidEmployee)
			{
				HttpSession session = request.getSession();
				String role = loginEmployee.getEmployeeRole();
				String name = loginEmployee.getEmployeeName();
				session.setAttribute("employeeId", employeeId);
				session.setAttribute("role", role);
				session.setAttribute("employeeName", name);
				System.out.println(" emplyee name " + role);
				switch(role)
				{
				case "Participant" :
								response.sendRedirect("participantHomePage.jsp");
								break;
								
				case "Admin" : 	response.sendRedirect("adminHomePage1.jsp");
				                break;
				                
				case "Coordinator" :
								response.sendRedirect("coordinatorHomePage1.jsp");
				                break;
				}
			}
			
			else {
				System.out.println("wrong password");
				request.setAttribute("errorMessage", "User Name or Password is Invalid!");
				request.getRequestDispatcher("welcome.jsp").forward(request, response);
			}
		}
		catch (Exception e) {
			// TODO: handle exception
			request.setAttribute("ErrorMsg", "Sorry can't connect to database.");
			request.getRequestDispatcher("error.jsp").forward(request, response);
		}
		
		
		
		
		
	}

}
