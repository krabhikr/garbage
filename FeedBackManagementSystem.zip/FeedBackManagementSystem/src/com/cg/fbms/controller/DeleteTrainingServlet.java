package com.cg.fbms.controller;

import java.io.IOException;

import javax.persistence.PersistenceException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.fbms.service.ITrainingCoordinatorService;
import com.cg.fbms.service.TrainingCoordinatorService;

@WebServlet("/DeleteTrainingServlet")
public class DeleteTrainingServlet extends HttpServlet{
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String courseId=request.getParameter("id");
		int cId =Integer.parseInt(courseId);
		ITrainingCoordinatorService trainingService = new TrainingCoordinatorService();
		try {
			
			Boolean delete = trainingService.deleteTrainingSession(cId);
			if(delete) {
				request.setAttribute("successMessage", "Training deleted successfully");
				request.getRequestDispatcher("editOrDelete.jsp").forward(request, response);
			}
			else {
				request.setAttribute("errorMessage", "Something went wrong! Try later");
				request.getRequestDispatcher("editOrDelete.jsp").forward(request, response);
			}
		}
		catch (PersistenceException p) {
			// TODO: handle exception
			System.err.println(p.getMessage());
			request.setAttribute("errorMessage", "Some error occurred, please verify all details");
			request.getRequestDispatcher("error.jsp").forward(request, response);
		}
	}
}
