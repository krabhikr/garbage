package com.cg.fbms.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.fbms.service.ITrainingCoordinatorService;
import com.cg.fbms.service.TrainingCoordinatorService;

@WebServlet("/GetPaticipantId")
public class GetParticipantIdController extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		ITrainingCoordinatorService coordinatorService = new TrainingCoordinatorService();
		List<Integer> allParticipantList = new ArrayList<Integer>();
		
		int selectedTrainingId = Integer.parseInt(request.getParameter("selectedTrainingId"));
		System.out.println(selectedTrainingId);
		try {
			allParticipantList = coordinatorService.getAllParticipantIdList(selectedTrainingId);
			System.out.println(allParticipantList);
			System.out.println("abc");
			request.setAttribute("allParticipantList",allParticipantList);
			request.setAttribute("selectedTrainingId",selectedTrainingId);
			request.getRequestDispatcher("enrollParticipant.jsp").forward(request, response);
		}catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
	}

}
