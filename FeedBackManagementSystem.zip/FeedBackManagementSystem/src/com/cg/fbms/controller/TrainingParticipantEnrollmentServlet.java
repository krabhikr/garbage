package com.cg.fbms.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.fbms.service.ITrainingCoordinatorService;
import com.cg.fbms.service.TrainingCoordinatorService;

@WebServlet("/TrainingParticipantEnrollment")
public class TrainingParticipantEnrollmentServlet extends HttpServlet{
		@Override
		protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			// TODO Auto-generated method stub
			int trainingId = Integer.parseInt(request.getParameter("selectedTrainingId"));
			int participantId = Integer.parseInt(request.getParameter("selectedParticipantId"));
			
			ITrainingCoordinatorService trainingCoordinator = new TrainingCoordinatorService();
			try {
				boolean status = trainingCoordinator.addParticipantEnrollment(trainingId, participantId);
				if(status) {
					System.out.println("Participant Enrolled successfully");
					request.setAttribute("successMessage", "Participant Enrolled successfully");
					request.setAttribute("errorMessage", "Some error occurred, please verify all details");
					request.getRequestDispatcher("enrollParticipant.jsp").forward(request, response);
					
				}
				else {
					request.setAttribute("errorMessage", "Some error occurred, please verify all details");
					request.getRequestDispatcher("enrollParticipant.jsp").forward(request, response);
				
			}
		}
			catch (Exception e) {
				request.setAttribute("ErrorMsg", "Sorry can't connect to database.");
				request.getRequestDispatcher("error.jsp").forward(request, response);
			}
			}
}
