package com.cg.fbms.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.fbms.service.CourseMaintenanceService;
import com.cg.fbms.service.ICourseMaintenance;

@WebServlet("/CheckCourseExistence")
public class CheckCourseExistenceServlet extends HttpServlet{
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String courseName =  request.getParameter("courseName");;
		int courseId   =  0;
		int identification = Integer.parseInt(request.getParameter("identification"));
		if(identification==2) {
			courseId = Integer.parseInt(request.getParameter("courseId"));
		}
		
			 
		
		System.out.println("course name " + courseName);
		RequestDispatcher dispatcher = null;
		try {
			System.out.println("caaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaammmmmmmmmmmm");
			ICourseMaintenance courseMaintenance = new CourseMaintenanceService();
			boolean isExist = courseMaintenance.checkCourseExistence(courseName);
			System.out.println("status " + isExist);
			if(isExist) {
				System.out.println("working fine" + identification);
				request.setAttribute("identification", identification);
				request.setAttribute("errorMessage", "Course already exist");
				if(identification==2) {
					System.out.println("in identification loop");
					request.setAttribute("courseId", courseId);
					
				}
				dispatcher = request.getRequestDispatcher("courseMaintenance1.jsp");
				dispatcher.forward(request, response);
				
			}
			else{
				System.out.println("in else loop");
				request.setAttribute("identification", identification);
				if(identification==2) {
					request.setAttribute("courseId", courseId);
					
				}
				request.setAttribute("courseFine", 1);
				request.setAttribute("courseName", courseName);
				dispatcher = request.getRequestDispatcher("courseMaintenance1.jsp");
				dispatcher.forward(request, response);
			}
		
		}catch (Exception e) {
			// TODO: handle exception
		}
	}
}
